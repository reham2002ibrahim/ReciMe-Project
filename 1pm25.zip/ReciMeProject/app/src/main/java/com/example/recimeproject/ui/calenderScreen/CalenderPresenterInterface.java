package com.example.recimeproject.ui.calenderScreen;

import androidx.lifecycle.LiveData;

import com.example.recimeproject.DataLayer.model.Meal;
import com.example.recimeproject.DataLayer.model.MealDate;

import java.util.Date;
import java.util.List;

public interface CalenderPresenterInterface {


  //  void getCalenderMeals() ;



    LiveData<List<Meal>> getMealsCalendered(Date date) ;


    void deleteCalendredMeal(String mealId) ;


}
