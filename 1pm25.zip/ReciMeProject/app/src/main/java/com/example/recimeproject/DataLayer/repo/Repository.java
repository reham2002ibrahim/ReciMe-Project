package com.example.recimeproject.DataLayer.repo;

import android.content.Context;
import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MediatorLiveData;

import com.example.recimeproject.DataLayer.local.LocalDataSource;
import com.example.recimeproject.DataLayer.model.Meal;
import com.example.recimeproject.DataLayer.model.MealDate;
import com.example.recimeproject.DataLayer.remote.NetworkCallback;
import com.example.recimeproject.DataLayer.remote.RemoteDataSource;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Repository {
    private static Repository instance;
    private final LocalDataSource localDataSource;
    private final RemoteDataSource remoteDataSource;

    private Repository(LocalDataSource localDataSource, RemoteDataSource remoteDataSource) {
        this.localDataSource = localDataSource;
        this.remoteDataSource = remoteDataSource;
    }

    public static synchronized Repository getInstance(LocalDataSource local , RemoteDataSource remote) {
        if (instance == null) {
            instance = new Repository(local , remote);
        }
        return instance;
    }


/*    public LiveData<List<Meal>> getAllMeals() {
        return localDataSource.getAllMeals();
    }*/

    public void fetchRandomMeal(NetworkCallback<Meal> callback) {
        remoteDataSource.getRandomMeal(new NetworkCallback<Meal>() {
            @Override
            public void onSuccess(Meal meal) {
            //    localDataSource.insertMeal(meal);
                callback.onSuccess(meal);
            }

            @Override
            public void onFailure(String errorMessage) {
                callback.onFailure(errorMessage);
            }
        });
    }
    public void searchMealsByLetters(NetworkCallback<List<Meal>> callback) {
        remoteDataSource.searchMealsByLetters(new NetworkCallback<List<Meal>>() {
            @Override
            public void onSuccess(List<Meal> meals) {
             /*   for (Meal meal : meals) {
                    localDataSource.insertMeal(meal);
                }*/
                callback.onSuccess(meals);
            }

            @Override
            public void onFailure(String errorMessage) {
                callback.onFailure(errorMessage);
            }
        });
    }
    public void getMealById(String mealId, NetworkCallback<Meal> callback) {
        remoteDataSource.getMealById(mealId, callback);
    }

    // detalis meals
    public void inserTotFav(String mealId) {
        getMealById(mealId, new NetworkCallback<Meal>() {
            @Override
            public void onSuccess(Meal meal) {
                if (meal != null) {
                    Log.d("NetworkCallback", "Retrieved meal object is not null: " + meal.getStrMeal());
                    localDataSource.inserTotFav(meal);
                    Log.d("fav meal inserted", "onSuccess: donee");
                } else {
                    Log.e("Error", "Retrieved meal object is null");
                }
            }

            @Override
            public void onFailure(String errorMessage) {
                Log.e("Error", "Failed to retrieve meal: " + errorMessage);
            }
        });
    }

    public void deleteFromFav (Meal meal) {
        localDataSource.deleteMeal(meal);
    }

    public void deleteFromCalender (String mealId) {
        localDataSource.deleteFromCalender(mealId);
    }



    public void inserTotCalendar(String mealId, Date date) {
        MealDate mealDate = new MealDate(mealId, date);
        localDataSource.inserTotCalendar(mealDate);
        Log.d("calendar meal inserted", "onSuccess: doneeeeeeeeeeeeeeeee");
    }


  /*  public void inserTotCalendar(String mealId, Date date) {
        getMealById(mealId, new NetworkCallback<Meal>() {
            @Override
            public void onSuccess(Meal meal) {
                MealDate mealDate = new MealDate(mealId, date);
                localDataSource.inserTotCalendar(mealDate);
                Log.d("calendar meal inserted", "onSuccess: doneeeeeeeeeeeeeeeee");
            }

            @Override
            public void onFailure(String errorMessage) {
                Log.e("Error", "Failed to retrieve meal: " + errorMessage);
            }
        });
    }*/


    // saved screen

    public LiveData<List<Meal>> getFavMeals() {
       return localDataSource.getFavoriteMeals() ;
    }

    public LiveData<List<Meal>> getMealsCalendered(Date date) {
        MediatorLiveData<List<Meal>> result = new MediatorLiveData<>();
        LiveData<List<String>> allMeals = localDataSource.getCalenderedDate(date);

        result.addSource(allMeals, mealIds -> {
            if (mealIds != null && !mealIds.isEmpty()) {
                List<Meal> meals = new ArrayList<>();
                for (String it : mealIds) {
                    Log.d("Repository", "Fetching mealId: " + it);
                    remoteDataSource.getMealById(it, new NetworkCallback<Meal>() {
                        @Override
                        public void onSuccess(Meal meal) {
                            Log.d("Repository", "Fetched meal: " + meal.getStrMeal());
                            meals.add(meal);
                            result.setValue(meals);
                        }
                        @Override
                        public void onFailure(String errorMessage) {
                            Log.e("Repository", "Error fetching meal");
                        }
                    });
                }
            } else {result.setValue(new ArrayList<>());}
        });
        return result;
    }


    // repo get list from local and pass it to remote to get info about each meal
//    public LiveData<List<Meal>> getCalenderdMeals(Date date) {
//        LiveData<List<String>> allMeals =   localDataSource.getCalenderedDate(date) ;
//        LiveData<List<Meal>> ans ;
//        for ( String it : allMeals) {
//            remoteDataSource.getMealById(it, NetworkCallback<Meal> callback);
//        }
//
//
//    }


    public LiveData<List<String>>getCalenderedDate(Date date){
        return  localDataSource.getCalenderedDate(date) ;
    }

/*
    public void getCalenderMeals(){
        localDataSource.getCalendarMeals() ;
    }*/


 /*   public  LiveData<List<Meal>> getMeals() {

        return localDataSource.getAllMeals() ;
    }*/




}
