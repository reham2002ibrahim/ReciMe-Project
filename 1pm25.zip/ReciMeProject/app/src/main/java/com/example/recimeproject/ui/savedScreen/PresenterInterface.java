package com.example.recimeproject.ui.savedScreen;

import androidx.lifecycle.LiveData;

import com.example.recimeproject.DataLayer.model.Meal;

import java.util.List;

public interface PresenterInterface {

    LiveData<List<Meal>> getFavMeals() ;

    void deleteFavMeal(Meal meal) ;

}
