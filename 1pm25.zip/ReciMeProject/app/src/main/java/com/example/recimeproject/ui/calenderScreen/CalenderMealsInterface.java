    package com.example.recimeproject.ui.calenderScreen;

    import com.example.recimeproject.DataLayer.model.Meal;

    import java.util.List;

    public interface CalenderMealsInterface {
        void showCalenderMeals(List<Meal> meals) ;



    }
