package com.example.recimeproject.DataLayer.remote;

public interface NetworkCallback<T> {
    void onSuccess(T result);
    void onFailure(String errorMessage);
}