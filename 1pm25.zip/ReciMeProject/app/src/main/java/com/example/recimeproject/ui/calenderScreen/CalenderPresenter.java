package com.example.recimeproject.ui.calenderScreen;

import androidx.lifecycle.LiveData;

import com.example.recimeproject.DataLayer.model.Meal;
import com.example.recimeproject.DataLayer.model.MealDate;
import com.example.recimeproject.DataLayer.repo.Repository;

import java.util.Date;
import java.util.List;

public class CalenderPresenter implements CalenderPresenterInterface {
    // private final SavedMeals view;
    private final Repository repository;

    public CalenderPresenter(Repository repo) {
        //  this.view = view;
        this.repository =repo;
    }

/*    @Override
    public void getCalenderMeals() {
       // repository.getCalenderMeals();
    }*/

    @Override
    public LiveData<List<Meal>>getMealsCalendered(Date date) {
       return repository.getMealsCalendered(date);
    }

    @Override
    public void deleteCalendredMeal(String mealId) {
        repository.deleteFromCalender(mealId);
    }


}
