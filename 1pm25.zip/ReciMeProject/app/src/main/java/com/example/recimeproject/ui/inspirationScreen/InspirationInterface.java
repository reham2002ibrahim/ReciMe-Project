package com.example.recimeproject.ui.inspirationScreen;

import com.example.recimeproject.DataLayer.model.Meal;

import java.util.List;

public interface InspirationInterface {

    void showRandomMeal(Meal meal);

    void showSuggestionMeals(List<Meal> meals);





}
