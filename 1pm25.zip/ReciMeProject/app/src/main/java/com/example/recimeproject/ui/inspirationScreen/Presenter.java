package com.example.recimeproject.ui.inspirationScreen;

import android.content.Context;

import com.example.recimeproject.DataLayer.model.Meal;
import com.example.recimeproject.DataLayer.remote.NetworkCallback;
import com.example.recimeproject.DataLayer.repo.Repository;

import java.util.List;

public class Presenter implements PresenterInterface {
    private final InspirationInterface view;
    private final Repository repository;

    public Presenter(Inspiration view, Repository repo) {
        this.view = view;
        this.repository = repo;
    }


    @Override
    public void getRandomMeal() {
        repository.fetchRandomMeal(new NetworkCallback<Meal>() {
            @Override
            public void onSuccess(Meal result) {
                view.showRandomMeal(result);
            }

            @Override
            public void onFailure(String errorMessage) {

            }
        });

    }

    @Override
    public void getSuggestionMeals() {
        repository.searchMealsByLetters(new NetworkCallback<List<Meal>>() {
            @Override
            public void onSuccess(List<Meal> result) {
                view.showSuggestionMeals(result);

            }

            @Override
            public void onFailure(String errorMessage) {

            }
        });
    }
}
