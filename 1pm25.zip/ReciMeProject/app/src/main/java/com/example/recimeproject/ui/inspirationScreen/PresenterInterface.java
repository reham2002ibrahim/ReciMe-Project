package com.example.recimeproject.ui.inspirationScreen;

public interface PresenterInterface {

    void getRandomMeal() ;
    void getSuggestionMeals() ;






}
