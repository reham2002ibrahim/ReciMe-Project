package com.example.recimeproject.DataLayer.remote;

import com.example.recimeproject.DataLayer.model.MealResponse;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiService {
    @GET("random.php")
    Call<MealResponse> getRandomMeal();

    @GET("lookup.php")
    Call<MealResponse> getMealById(@Query("i") String mealId);

    @GET("search.php")
    Call<MealResponse> searchMealsByLetter(@Query("f") String letter);

    @GET("filter.php")
    Call<MealResponse> getMealsByCategory(@Query("c") String category);

    @GET("list.php?c=list")
    Call<MealResponse> getCategories();
}