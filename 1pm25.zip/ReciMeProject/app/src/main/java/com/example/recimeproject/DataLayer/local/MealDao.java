package com.example.recimeproject.DataLayer.local;
import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import com.example.recimeproject.DataLayer.model.Meal;
import com.example.recimeproject.DataLayer.model.MealDate;

import java.util.Date;
import java.util.List;

@Dao
public interface MealDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertMeal(Meal meal);

    @Delete
    void deleteMeal(Meal meal);

    @Query("SELECT * FROM meals")
    LiveData<List<Meal>> getAllMeals();




    @Query("SELECT * FROM meals WHERE idMeal = :mealId")
    LiveData<Meal> getMealById(String mealId);



    @Query("SELECT * FROM meals WHERE fav = true ")
    LiveData<List<Meal>> getFavMeals();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertMealDate(MealDate mealDate);

    @Query("SELECT mealId FROM calendar WHERE date = :date")
    LiveData<List<String>> getMealIdsByDate(Date date);

    @Query("DELETE  FROM calendar where mealId = :mealId")
    void deleteCalendredMeal(String mealId);

   /* @Query("SELECT * FROM meals WHERE idMeal = :mealId LIMIT 1")
    Meal getMealByIdSync(String mealId);*/
    /*@Query("SELECT * FROM calendar WHERE mealId = :mealId")
    LiveData<List<MealDate>> getMealDatesByMealId(String mealId);
*/
/*
    @Query("SELECT * FROM calendar WHERE date = :date")
    LiveData<List<MealDate>> getMealDatesByDate(Date date);*/

    /*@Query("SELECT * FROM meals WHERE calender = 1 ")
    LiveData<Meal> getCalenderMeals();*/

   /* @Query("SELECT * FROM meals WHERE calenderDate = :mealDate ")
    LiveData<Meal> getCalenderMealByDate(Date mealDate);*/
}