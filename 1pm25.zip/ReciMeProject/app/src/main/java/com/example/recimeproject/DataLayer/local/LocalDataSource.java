package com.example.recimeproject.DataLayer.local;

import android.content.Context;
import android.util.Log;

import androidx.lifecycle.LiveData;
import com.example.recimeproject.DataLayer.model.Meal;
import com.example.recimeproject.DataLayer.model.MealDate;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class LocalDataSource {
    private final MealDao mealDao;
    private LiveData <List<Meal>> favoriteMeals;
    private LiveData <List<Meal>> calendarMeals;
    private static LocalDataSource instance  = null ;

   /* public LocalDataSource(Context context) {
        AppDatabase db = AppDatabase.getInstance(context); // استخدام getInstance
        this.mealDao = db.mealDao();
    }
*/

    private LocalDataSource(Context context) {
        AppDatabase db = AppDatabase.getInstance(context);
        this.mealDao = db.mealDao();
        this.favoriteMeals = mealDao.getFavMeals();
      // this.calendarMeals = new ArrayList<>();
    }

    public  static  LocalDataSource getInstance(Context context){
        if (instance == null ) {
            instance = new LocalDataSource(context) ;
        }
        return  instance ;
    }


    public LiveData<List<Meal>> getFavoriteMeals() {
        return favoriteMeals;
    }

    /*public void insertMeal(Meal meal) {
        new Thread(() -> {
            mealDao.insertMeal(meal);
            Log.d("LocalDataSource", "Meal inserted: " + meal.getStrMeal());
        }).start();
    }

     */

    public void inserTotFav(Meal meal) {
        if (meal != null) {
            Log.d("LocalDataSource", "Meal object is not null: " + meal.getStrMeal());
            if (meal.getFav() == null) {
                meal.setFav(false);
                Log.d("LocalDataSource", "Meal fav attribute was null, set to false: " + meal.getStrMeal());
            }
            if (!meal.getFav()) {
                Log.d("LocalDataSource", "Meal fav attribute is false: " + meal.getStrMeal());
                new Thread(() -> {
                    meal.setFav(true);
                    mealDao.insertMeal(meal);
                    Log.d("LocalDataSource", "Favorite meal inserted in thread: " + meal.getStrMeal());
                }).start();
            } else {
                Log.e("LocalDataSource", "Meal fav attribute is already true");
            }
        } else {
            Log.e("LocalDataSource", "Meal object is null");
        }
    }

 /*
   public List<Meal> getFavoriteMeals() { // like dtaa
        return favoriteMeals;
    }*/

   /* public void inserTotCalendar(MealDate mealDate) {
        new Thread(() -> {
            Meal meal = mealDao.getMealByIdSync(mealDate.getMealId());
            if (meal != null) {
                mealDao.insertMealDate(mealDate);
                Log.d("LocalDataSource", "Calendar meal date inserted: " + mealDate.getDate());
            } else {
                Log.e("Error", "Meal with ID " + mealDate.getMealId() + " does not exist.");
            }
        }).start();
    }
*/
    public void inserTotCalendar(MealDate mealDate) {
        new Thread(() -> {
            mealDao.insertMealDate(mealDate);
            Log.d("LocalDataSource", "Calendar meal date inserted: " + mealDate.getDate());
        }).start();
    }


    // last
/* public void inserTotCalendar(MealDate mealDate) {
     new Thread(() -> {
         mealDao.insertMealDate(mealDate);
         Log.d("LocalDataSource", "Calendar meal date inserted: " + mealDate.getDate());
     }).start();
 }*/

 public LiveData<List<String>> getCalenderedDate(Date date) {
     return mealDao.getMealIdsByDate(date);
 }

/*    public LiveData<List<MealDate>> getCalendarMeals() {
        return mealDao.getMealDatesByDate((java.sql.Date) new Date());
    }*/
/*
    public void inserTotCalendar(Meal meal) {

        // make sure meal -- > calender =1 and date != null

        new Thread(() -> {
         //   calendarMeals.add(meal);

            mealDao.insertMeal(meal);
            Log.d("LocalDataSource", "Calendar meal inserted: " + meal.getStrMeal());
        }).start();
    }*/
/*
    public List<Meal> getCalendarMeals() {
        return calendarMeals;
    }
*/



    public void deleteMeal(Meal meal) {
        new Thread(() -> mealDao.deleteMeal(meal)).start();
    }

    public void deleteFromCalender(String mealId) {
        new Thread(() -> mealDao.deleteCalendredMeal(mealId)).start();
    }
}
