package com.example.recimeproject.utils;

import com.example.recimeproject.DataLayer.model.Meal;

public interface OnRemoveClickListener {
    void onRemoveClick(Meal meal);
}
