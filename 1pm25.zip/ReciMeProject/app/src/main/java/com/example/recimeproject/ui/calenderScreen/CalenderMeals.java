package com.example.recimeproject.ui.calenderScreen;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.CalendarView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.recimeproject.DataLayer.local.LocalDataSource;
import com.example.recimeproject.DataLayer.model.Meal;
import com.example.recimeproject.DataLayer.remote.RemoteDataSource;
import com.example.recimeproject.DataLayer.repo.Repository;
import com.example.recimeproject.R;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class CalenderMeals extends AppCompatActivity implements CalenderMealsInterface {
    private CalenderPresenter presenter;
    private RecyclerView recyclerView;
    private CalendredAdapter adapter;
    private Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calender_meals);

        presenter = new CalenderPresenter(Repository.getInstance(LocalDataSource.getInstance(this), new RemoteDataSource()));

        CalendarView calendarView = findViewById(R.id.calendarView);
        Calendar calendar = Calendar.getInstance();

        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        long curDate = calendar.getTimeInMillis();

        calendar.add(Calendar.DAY_OF_YEAR, 6);
        long nxtDate = calendar.getTimeInMillis();
        calendarView.setMinDate(curDate);
        calendarView.setMaxDate(nxtDate);
        calendarView.setDate(curDate);

        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            Calendar chosenDate = Calendar.getInstance();
            chosenDate.set(year, month, dayOfMonth);
            chosenDate.set(Calendar.HOUR_OF_DAY, 0);
            chosenDate.set(Calendar.MINUTE, 0);
            chosenDate.set(Calendar.SECOND, 0);
            chosenDate.set(Calendar.MILLISECOND, 0);
            Date date = chosenDate.getTime();

            presenter.getMealsCalendered(date).observe(this, this::showCalenderMeals);
        });

        recyclerView = findViewById(R.id.rvFavMeals);
        btnBack = findViewById(R.id.btnBack);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));

        adapter = new CalendredAdapter(this, new ArrayList<>(), meal -> {
            // Handle remove meal event
           presenter.deleteCalendredMeal(meal.getIdMeal());

        });

        recyclerView.setAdapter(adapter);

        presenter.getMealsCalendered(new Date(curDate)).observe(this, this::showCalenderMeals);

        btnBack.setOnClickListener(v -> {
            finish();
        });
    }

    @Override
    public void showCalenderMeals(List<Meal> meals) {
        adapter.setMealList(meals);

        for (Meal meal : meals) {
            Log.d("CalenderMeals", "Meal: " + (meal.getStrMeal() != null ? meal.getStrMeal() : "No Name"));
        }
    }
}


/*package com.example.recimeproject.ui.calenderScreen;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.recimeproject.DataLayer.local.LocalDataSource;
import com.example.recimeproject.DataLayer.model.Meal;
import com.example.recimeproject.DataLayer.remote.RemoteDataSource;
import com.example.recimeproject.DataLayer.repo.Repository;
import com.example.recimeproject.R;
import com.example.recimeproject.ui.savedScreen.FavMealsAdapter;
import com.example.recimeproject.ui.savedScreen.Presenter;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class CalenderMeals extends AppCompatActivity implements CalenderMealsInterface {
    private CalenderPresenter presenter;
    private ImageView imgMeal, imgMealThumb;
    private TextView txtMealName;
    RecyclerView recyclerView ;
    FavMealsAdapter adapter  ;
    Button btnBack  ;

    LiveData<List<Meal>> liveFavData ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calender_meals);

        presenter = new CalenderPresenter(Repository.getInstance(LocalDataSource.getInstance(this), new RemoteDataSource()));

        CalendarView calendarView = findViewById(R.id.calendarView);
        Calendar calendar = Calendar.getInstance();

        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        long curDate = calendar.getTimeInMillis();
        calendar.add(Calendar.DAY_OF_YEAR, 6);
        long nxtDate = calendar.getTimeInMillis();

        calendarView.setMinDate(curDate);
        calendarView.setMaxDate(nxtDate);
        calendarView.setDate(curDate);
        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            Calendar chosedDate = Calendar.getInstance();
            chosedDate.set(year, month, dayOfMonth);
            chosedDate.set(Calendar.HOUR_OF_DAY, 0);
            chosedDate.set(Calendar.MINUTE, 0);
            chosedDate.set(Calendar.SECOND, 0);
            chosedDate.set(Calendar.MILLISECOND, 0);
            Date date = chosedDate.getTime();
            presenter.getMealsCalendered(date).observe(this, this::showCalenderMeals);
        });

        recyclerView = findViewById(R.id.rvFavMeals);
        btnBack = findViewById(R.id.btnBack);
        //   imgMealThumb = findViewById(R.id.imgMealThumb);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

        presenter.getMealsCalendered(new Date(curDate)).observe(this, this::showCalenderMeals);


    }

    @Override
    public void showCalenderMeals(List<Meal> meals) {
        for (Meal meal : meals) {
            Log.d("CalenderMeals", "Meal: " + meal.getStrMeal());
        }
    }
}
*/

/*package com.example.recimeproject.ui.calenderScreen;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.recimeproject.DataLayer.local.LocalDataSource;
import com.example.recimeproject.DataLayer.model.Meal;
import com.example.recimeproject.DataLayer.remote.RemoteDataSource;
import com.example.recimeproject.R;
import com.example.recimeproject.DataLayer.repo.Repository;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class CalenderMeals extends AppCompatActivity implements CalenderMealsInterface{
    private CalenderPresenter presenter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calender_meals);

        presenter = new CalenderPresenter(Repository.getInstance( LocalDataSource.getInstance(this) , new RemoteDataSource() ));


        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, 1);
        Date tomorrow = calendar.getTime();

        presenter.getMealsCalendered(tomorrow).observe(this, this::showCalenderMeals);
       // presenter.getMealsCalendered(new Date()).observe(this, this::showCalenderMeals);
    }

    @Override
    public void showCalenderMeals(List<Meal> meals) {
        for (Meal meal : meals) {
            Log.d("CalenderMeals", "Meal: " + meal.getStrMeal());
        }
    }
}





 */

/*
public class CalenderMeals extends AppCompatActivity implements CalenderMealsInterface {
    private CalenderPresenter presenter;
    private RecyclerView recyclerView;
    private DayCardAdapter adapter;
    private List<DayCard> dayCards;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calender_meals);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        dayCards = createDayCards();
        adapter = new DayCardAdapter(dayCards, dayCard -> {
            presenter.getMealsCalendered(dayCard.getDate()).observe(this, this::showCalenderMeals);
        });
        recyclerView.setAdapter(adapter);

        presenter = new CalenderPresenter(Repository.getInstance( LocalDataSource.getInstance(this) , new RemoteDataSource() ));
    }

    private List<DayCard> createDayCards() {
        List<DayCard> cards = new ArrayList<>();
        Calendar calendar = Calendar.getInstance();

        for (int i = 0; i < 7; i++) {
            Date date = calendar.getTime();
            String day = new SimpleDateFormat("EEEE").format(date);
            cards.add(new DayCard(date, day));
            calendar.add(Calendar.DAY_OF_YEAR, 1);
        }
        return cards;
    }

    @Override
    public void showCalenderMeals(List<Meal> meals) {
        for (Meal meal : meals) {
            Log.d("CalenderMeals", "Meal: " + meal.getStrMeal());
        }
    }
}
*/
