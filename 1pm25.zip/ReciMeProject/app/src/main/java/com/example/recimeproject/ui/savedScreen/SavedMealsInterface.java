package com.example.recimeproject.ui.savedScreen;

import com.example.recimeproject.DataLayer.model.Meal;

import java.util.List;

public interface SavedMealsInterface {

    void showFavMeals(List<Meal> meals) ;
}
