package com.example.recimeproject.ui.detailsOfMealScreen;

import com.example.recimeproject.DataLayer.model.Meal;

public interface DetailsOfMealInterface {

    void showSelectedMeal(Meal meal) ;


}
