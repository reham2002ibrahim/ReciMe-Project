package com.example.recimeproject.ui.savedScreen;
import android.content.Context;

import androidx.lifecycle.LiveData;

import com.example.recimeproject.DataLayer.model.Meal;
import com.example.recimeproject.DataLayer.repo.Repository;

import java.util.List;

public class Presenter implements PresenterInterface{

   // private final SavedMeals view;
    private final Repository repository;

    public Presenter(Repository repo ) {
      //  this.view = view;
        this.repository = repo ;
    }


    @Override
    public LiveData<List<Meal>> getFavMeals() {
        return  repository.getFavMeals();
    }

    @Override
    public void deleteFavMeal(Meal meal) {
        repository.deleteFromFav(meal);
    }



/*
    @Override
    public LiveData<List<Meal>> getFavMeals() {
        return  repository.getFavMeals();

    }*/
}
