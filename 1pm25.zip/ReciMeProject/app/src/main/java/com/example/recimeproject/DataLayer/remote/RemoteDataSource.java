package com.example.recimeproject.DataLayer.remote;

import android.util.Log;
import com.example.recimeproject.DataLayer.model.Meal;
import com.example.recimeproject.DataLayer.model.MealResponse;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import java.util.ArrayList;
import java.util.List;

public class RemoteDataSource {
    private static final String BASE_URL = "https://www.themealdb.com/api/json/v1/1/";
    private final ApiService apiService;

    public RemoteDataSource() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        this.apiService = retrofit.create(ApiService.class);
    }

    public void getRandomMeal(NetworkCallback<Meal> callback) {
        apiService.getRandomMeal().enqueue(new Callback<MealResponse>() {
            @Override
            public void onResponse(Call<MealResponse> call, Response<MealResponse> response) {
                if (response.isSuccessful() && response.body() != null && !response.body().getMeals().isEmpty()) {
                    Meal meal = response.body().getMeals().get(0);
                    Log.d("RemoteDataSource", "Random Meal loaded: " + meal.getStrMeal());
                    callback.onSuccess(meal);
                } else {
                    Log.e("RemoteDataSource", "Random Meal: No data found");
                    callback.onFailure("No data found");
                }
            }

            @Override
            public void onFailure(Call<MealResponse> call, Throwable t) {
                Log.e("RemoteDataSource", "Random Meal API Error: " + t.getMessage());
                callback.onFailure(t.getMessage());
            }
        });
    }
    public void getMealById(String mealId,NetworkCallback<Meal> callback){
        apiService.getMealById(mealId).enqueue(new Callback<MealResponse>() {
            @Override
            public void onResponse(Call<MealResponse> call, Response<MealResponse> response) {
                callback.onSuccess(response.body().getMeals().get(0));

            }

            @Override
            public void onFailure(Call<MealResponse> call, Throwable throwable) {

            }
        });

    }

    public void searchMealsByLetter(String letter, NetworkCallback<List<Meal>> callback) {
        apiService.searchMealsByLetter(letter).enqueue(new Callback<MealResponse>() {
            @Override
            public void onResponse(Call<MealResponse> call, Response<MealResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<Meal> meals = response.body().getMeals();
                    Log.d("RemoteDataSource", "Meals by letter " + letter + " loaded: " + meals.size());
                    callback.onSuccess(meals);
                } else {
                    Log.e("RemoteDataSource", "Meals by letter " + letter + ": No data found");
                    callback.onFailure("No data found");
                }
            }

            @Override
            public void onFailure(Call<MealResponse> call, Throwable t) {
                Log.e("RemoteDataSource", "Meals by letter " + letter + " API Error: " + t.getMessage());
                callback.onFailure(t.getMessage());
            }
        });
    }
    // اخلا تعديل


    public void searchMealsByLetters(NetworkCallback<List<Meal>> callback) {
        List<Meal> allMeals = new ArrayList<>();
        String[] letters = {"M"};
        int[] counter = {0};
        for (String letter : letters) {
            apiService.searchMealsByLetter(letter).enqueue(new Callback<MealResponse>() {
                @Override
                public void onResponse(Call<MealResponse> call, Response<MealResponse> response) {
                    if (response.isSuccessful() && response.body() != null) {
                        List<Meal> meals = response.body().getMeals();
                        allMeals.addAll(meals);
                    }
                    checkCompletion();
                }
                @Override
                public void onFailure(Call<MealResponse> call, Throwable t) {
                    Log.e("RemoteDataSource", "Meals by letter " + letter + " API Error: " + t.getMessage());
                    checkCompletion();
                }
                private void checkCompletion() {
                    counter[0]++;
                    if (counter[0] == letters.length) {
                        if (allMeals.isEmpty()) {
                            callback.onFailure("No data found for any letter");
                        } else {
                            callback.onSuccess(allMeals);
                        }
                    }
                }
            });
        }
    }



}
