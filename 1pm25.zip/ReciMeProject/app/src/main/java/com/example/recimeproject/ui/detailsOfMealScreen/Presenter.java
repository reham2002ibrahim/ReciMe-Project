package com.example.recimeproject.ui.detailsOfMealScreen;

import android.content.Context;

import com.example.recimeproject.DataLayer.model.Meal;
import com.example.recimeproject.DataLayer.remote.NetworkCallback;
import com.example.recimeproject.DataLayer.repo.Repository;

import java.util.Date;

public class Presenter implements PresenterInterface{
    private final DetailsOfMeal view;
    private final Repository repository;

    public Presenter(DetailsOfMeal view,Repository repo) {
        this.view = view;
        this.repository =repo ;
    }

    @Override
    public void getSelectedMeal(String mealId) {
        repository.getMealById(mealId, new NetworkCallback<Meal>() {
            @Override
            public void onSuccess(Meal result) {
                view.showSelectedMeal(result);
            }

            @Override
            public void onFailure(String errorMessage) {

            }
        });


    }

    @Override
    public void putSavedMeal(String mealId) {
        repository.inserTotFav(mealId);
    }


    @Override
    public void putCalenderMeal(String mealId, Date date) {
        repository.inserTotCalendar(mealId, date);
    }

}
